<?php

return [
    'paths' => ['api/*', 'storage/uploads/users/*'],  // Tambahkan jalur penyimpanan
    'allowed_methods' => ['*'],
    'allowed_origins' => ['*'],  // Ubah '*' ke alamat frontend spesifik jika diperlukan
    'allowed_headers' => ['*'],
    'supports_credentials' => false,
];

